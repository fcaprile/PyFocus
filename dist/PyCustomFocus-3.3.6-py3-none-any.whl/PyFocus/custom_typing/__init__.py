
Matrix = list  # Actually it's a 2D numpy array
Matrix3D = list # Actually it's a 3D numpy array of nz, ny, nx
